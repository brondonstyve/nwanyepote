<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateReponseCommentaireEvenementParticipatifsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('reponse_commentaire_evenement_participatifs', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('commentaire')->index()->unsigned();
            $table->bigInteger('evenement')->index()->unsigned();
            $table->string('nom');
            $table->string('email');
            $table->string('cweb')->nullable();
            $table->text('comment');
            $table->foreign('commentaire')->references('id')->on('commentaire_evenement_participatifs')->onDelete('cascade') ;
            $table->foreign('evenement')->references('id')->on('evenementparticipatifs')->onDelete('cascade') ;
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('reponse_commentaire_evenement_participatifs');
    }
}
