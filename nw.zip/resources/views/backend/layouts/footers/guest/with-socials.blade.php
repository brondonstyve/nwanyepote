  <footer class="footer pb-5">
      <div class="container">
          <div class="row">
              <div class="col-8 mx-auto text-center mt-1">
                  <p class="mb-0 text-secondary">
                      Copyright © JastyTech {{ now()->year }} <br> Soft by <a style="color: #252f40;" href="mailto:brondonstyve@gmail.com"
                          class="font-weight-bold ml-1" target="_blank">jastydata</a>
              </div>
              </p>
          </div>
      </div>
      </div>
  </footer>
